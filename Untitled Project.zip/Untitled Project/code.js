






textInput("resolt", getText("text_input")


);onEvent("Upload", "click", function( ) {
	console.log("text_input current text: " + getText("text_input"));
	textInput("resolt", getText("text_input"));
});
